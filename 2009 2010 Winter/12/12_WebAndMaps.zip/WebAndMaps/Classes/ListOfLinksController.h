//
//  ListOfLinksController.h
//  Untitled
//
//  Created by Alan Cannistraro on 2/11/10.
//  Copyright 2010 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ListOfLinksController : UITableViewController <UIWebViewDelegate>
{

}

@end
