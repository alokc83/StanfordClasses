//
//  RetainCountTestAppDelegate.m
//  RetainCountTest
//
//  Created by CS193P on 1/12/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "RetainCountTestAppDelegate.h"

@implementation RetainCountTestAppDelegate

@synthesize window;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    

    // Override point for customization after application launch
    [window makeKeyAndVisible];
}

- (IBAction)runMyTest
{
	NSString *thisString = [NSString stringWithString:@"Hello"];
	NSLog(@"String retain count is %d", [thisString retainCount]);
	
	[thisString retain];
	NSLog(@"String retain count is %d", [thisString retainCount]);

	[thisString release];
	NSLog(@"String retain count is %d", [thisString retainCount]);
	
	[thisString release];
	NSLog(@"Hey! I'm still running!!!  (But I'm about to crash...)");
}


- (void)dealloc {
    [window release];
    [super dealloc];
}


@end
