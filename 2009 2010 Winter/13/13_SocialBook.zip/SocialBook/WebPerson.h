//
//  WebPerson.h
//  SocialBook
//
//  Created by Alexandre Aybes on 5/27/08.
//  Copyright 2008 Apple, Inc.. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface WebPerson : NSObject {
    NSString *firstName;
    NSString *lastName;
    NSString *urlString;
}

@property (nonatomic, copy) NSString *firstName;
@property (nonatomic, copy) NSString *lastName;
@property (nonatomic, copy) NSString *urlString;

@end
