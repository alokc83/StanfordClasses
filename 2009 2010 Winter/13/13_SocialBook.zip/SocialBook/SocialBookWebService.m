//
//  SocialBookWebService.m
//  SocialBook
//
//  Created by Alexandre Aybes on 5/27/08.
//  Copyright 2008 Apple, Inc.. All rights reserved.
//

#import "SocialBookWebService.h"
#import "WebPerson.h"


@implementation SocialBookWebService

+ (void)addPersonWithFirst:(NSString*)first last:(NSString*)last url:(NSString*)url toArray:(NSMutableArray*)array
{
    WebPerson *person = [[WebPerson alloc] init];
    person.firstName = first;
    person.lastName = last;
    person.urlString = url;
    [array addObject:person];
    [person release];
}

- (id)init
{
    if ((self = [super init])) {
        people = [[NSMutableArray alloc] init];
        
        [SocialBookWebService addPersonWithFirst:@"Ana" last:@"Haro" url:@"http://social/ana-haro" toArray:people];
        [SocialBookWebService addPersonWithFirst:@"Paul" last:@"Haro" url:@"http://social/paul-haro" toArray:people];
        [SocialBookWebService addPersonWithFirst:@"John" last:@"Appleseed" url:@"http://social/john-applesee" toArray:people];
        [SocialBookWebService addPersonWithFirst:@"Antoine" last:@"Aybes" url:@"http://social/antoine-aybes" toArray:people];
        [SocialBookWebService addPersonWithFirst:@"Adrien" last:@"Aybes" url:@"http://social/adrien-aybes" toArray:people];
    }
    
    return self;
}

- (void)dealloc
{
    [people release];
    
    [super dealloc];
}

- (NSArray*)webPeople
{
    return [[people copy] autorelease];;
}

@end
