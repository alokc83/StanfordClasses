//
//  SocialBookWebService.h
//  SocialBook
//
//  Created by Alexandre Aybes on 5/27/08.
//  Copyright 2008 Apple, Inc.. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SocialBookWebService : NSObject {
    NSMutableArray *people;
}

// returns an array of WebPerson instances
- (NSArray*)webPeople;

@end
