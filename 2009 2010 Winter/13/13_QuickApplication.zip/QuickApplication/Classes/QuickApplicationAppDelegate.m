//
//  QuickApplicationAppDelegate.m
//  QuickApplication
//
//  Created by Alexandre Aybes on 5/17/08.
//  Copyright Apple, Inc. 2008. All rights reserved.
//

#import "QuickApplicationAppDelegate.h"

#import <AddressBookUI/AddressBookUI.h>
#import <AddressBook/AddressBook.h>

@implementation QuickApplicationAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(UIApplication *)application {
	ABPersonViewController *personViewController = [[ABPersonViewController alloc] init];
    navigationController = [[UINavigationController alloc] initWithRootViewController:personViewController];
    [personViewController release];

    ABRecordRef person = ABPersonCreate();
    ABRecordSetValue(person, kABPersonFirstNameProperty, CFSTR("John"), NULL);
    ABRecordSetValue(person, kABPersonLastNameProperty, CFSTR("Appleseed"), NULL);
    personViewController.displayedPerson = person;
    CFRelease(person);

	personViewController.allowsEditing = YES;

    [window addSubview:navigationController.view];
}

- (void)dealloc {
    [navigationController release];
	[window release];
	[super dealloc];
}


@end
