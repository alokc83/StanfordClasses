//
//  QuickApplicationAppDelegate.h
//  QuickApplication
//
//  Created by Alexandre Aybes on 5/17/08.
//  Copyright Apple, Inc. 2008. All rights reserved.
//

#import <UIKit/UIKit.h>

@class QuickApplicationViewController;

@interface QuickApplicationAppDelegate : NSObject <UIApplicationDelegate> {
	IBOutlet UIWindow *window;
	UINavigationController *navigationController;
}

@property (nonatomic, retain) UIWindow *window;

@end

