//
//  MultiTouchDemoAppDelegate.h
//  MultiTouchDemo
//
//  Created by Jason Beaver on 5/29/08.
//  Copyright Apple Inc. 2008. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MultiTouchDemoViewController;

@interface MultiTouchDemoAppDelegate : NSObject <UIApplicationDelegate> {
	IBOutlet UIWindow *window;
	IBOutlet MultiTouchDemoViewController *viewController;
}

@property (nonatomic, retain) UIWindow *window;
@property (nonatomic, retain) MultiTouchDemoViewController *viewController;

@end

