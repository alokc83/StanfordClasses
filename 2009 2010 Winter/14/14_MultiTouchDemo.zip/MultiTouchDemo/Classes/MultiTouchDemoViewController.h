//
//  MultiTouchDemoViewController.h
//  MultiTouchDemo
//
//  Created by Jason Beaver on 5/29/08.
//  Copyright Apple Inc. 2008. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MultiTouchDemoViewController : UIViewController {

}

@end

