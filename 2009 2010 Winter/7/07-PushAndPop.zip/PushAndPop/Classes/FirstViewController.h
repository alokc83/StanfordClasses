//
//  FirstViewController.h
//  PushAndPop
//

#import <UIKit/UIKit.h>


@interface FirstViewController : UIViewController {

}

- (IBAction)push:(id)sender;

@end
