//
//  ScrolliPadViewController.h
//  ScrolliPad
//
//  Created by Josh Shaffer on 1/28/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScrolliPadViewController : UIViewController {
    UIImageView *imageView;
}

@end

