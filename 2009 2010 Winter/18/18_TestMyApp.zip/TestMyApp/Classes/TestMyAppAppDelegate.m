//
//  TestMyAppAppDelegate.m
//  TestMyApp
//
//  Created by Evan Doll on 12/2/08.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//

#import "TestMyAppAppDelegate.h"

@implementation TestMyAppAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after application launch
    [window makeKeyAndVisible];    
}


- (void)dealloc {
    [window release];
    [super dealloc];
}


@end
