//
//  Person.h
//  TestMyApp
//
//  Created by Evan Doll on 12/2/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Person : NSObject {
    NSString *displayName;
}

@property (copy) NSString *displayName;

@end
