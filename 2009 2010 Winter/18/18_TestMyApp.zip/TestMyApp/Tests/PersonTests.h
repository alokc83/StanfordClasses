//
//  PersonTests.h
//  TestMyApp
//
//  Created by Evan Doll on 12/2/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface PersonTests : SenTestCase {

}

@end
