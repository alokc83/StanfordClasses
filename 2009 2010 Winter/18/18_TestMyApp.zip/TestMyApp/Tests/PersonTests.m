//
//  PersonTests.m
//  TestMyApp
//
//  Created by Evan Doll on 12/2/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "PersonTests.h"
#import "Person.h"

@implementation PersonTests

- (void)testCreatePerson
{
    Person *person = [[Person alloc] init];
    STAssertNotNil(person, nil);
}

- (void)testSetDisplayName
{
    NSString *displayName = @"Paul";
    Person *person = [[Person alloc] init];
    person.displayName = displayName;
    STAssertEqualObjects(displayName, person.displayName, nil);
}

@end
