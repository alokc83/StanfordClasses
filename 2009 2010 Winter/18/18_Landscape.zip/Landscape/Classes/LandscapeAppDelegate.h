//
//  LandscapeAppDelegate.h
//  Landscape
//

#import <UIKit/UIKit.h>

@class LandscapeViewController;

@interface LandscapeAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    LandscapeViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet LandscapeViewController *viewController;

@end

