//
//  LandscapeViewController.m
//  Landscape
//

#import "LandscapeViewController.h"

@implementation LandscapeViewController

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return UIInterfaceOrientationIsLandscape(interfaceOrientation);
}

@end
