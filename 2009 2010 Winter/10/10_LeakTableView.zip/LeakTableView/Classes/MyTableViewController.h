//
//  MyTableViewController.h
//  MyTableView
//
//  Created by Evan Doll on 10/21/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface MyTableViewController : UITableViewController {
    NSArray *names;
}

@end
