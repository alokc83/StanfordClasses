//
//  MyTableViewController.m
//  MyTableView
//
//  Created by Evan Doll on 10/21/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "MyTableViewController.h"


@implementation MyTableViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        names = [[NSArray alloc] initWithObjects:@"Paul", @"Josh", @"Al", @"Dave",@"Paul", nil];
    }
    return self;
}

- (void)dealloc
{
    [names release];
    
    [super dealloc];
}

- (void)viewWillAppear:(BOOL)animated
{    
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    
    for (int i=0; i < 10000; i++) {
        
        if ((i % 100) == 0) {
            [pool drain];
            pool = [[NSAutoreleasePool alloc] init];
        }
        
        NSString *string = @"Foo";
        string = [string lowercaseString];
        string = [string stringByAppendingFormat:@"%d", 42];
        
    }
    
    [pool drain];
    
    [super viewWillAppear:animated];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    
    return [names count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:nil] autorelease];
    
    cell.textLabel.text = [names objectAtIndex:indexPath.row];
    
    return cell;
}

@end
