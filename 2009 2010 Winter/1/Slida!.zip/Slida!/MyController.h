#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface MyController : NSObject /* Specify a superclass (eg: NSObject or NSView) */ {
    IBOutlet UILabel *label;
    IBOutlet UISlider *slider;
}
- (IBAction)myAction1:(id)sender;
@end
