//
//  Slida_AppDelegate.m
//  Slida!
//
//  Created by CS193P on 1/5/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "Slida_AppDelegate.h"

@implementation Slida_AppDelegate

@synthesize window;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    

    // Override point for customization after application launch
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [window release];
    [super dealloc];
}


@end
