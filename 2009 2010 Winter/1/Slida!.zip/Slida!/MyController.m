#import "MyController.h"

@implementation MyController
- (IBAction)myAction1:(id)sender {
	int	value = slider.value;
    label.text = [NSString stringWithFormat:@"%d", value];
}
@end
