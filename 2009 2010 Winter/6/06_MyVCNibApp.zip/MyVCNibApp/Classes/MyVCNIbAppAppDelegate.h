//
//  MyVCNIbAppAppDelegate.h
//  MyVCNIbApp
//
//  Created by Alan Cannistraro on 1/21/10.
//  Copyright Apple 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MyVCNIbAppViewController;

@interface MyVCNIbAppAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    MyVCNIbAppViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet MyVCNIbAppViewController *viewController;

@end

