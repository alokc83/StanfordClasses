//
//  MyVCNIbAppViewController.h
//  MyVCNIbApp
//
//  Created by Alan Cannistraro on 1/21/10.
//  Copyright Apple 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyVCNIbAppViewController : UIViewController {

	IBOutlet UILabel *label;
	IBOutlet UISlider *slider;
}

@end

