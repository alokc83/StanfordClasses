//
//  MyTableViewAppDelegate.m
//  MyTableView
//

#import "MyTableViewAppDelegate.h"
#import "MyTableViewController.h"

@implementation MyTableViewAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    myTableViewController = [[MyTableViewController alloc] initWithStyle:UITableViewStylePlain];
    myTableViewController.view.frame = [UIScreen mainScreen].applicationFrame;
    
    [window addSubview:myTableViewController.view];
    
    // Override point for customization after application launch
    [window makeKeyAndVisible];
    
    // Register for badges, sounds and alerts
    [application registerForRemoteNotificationTypes:UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert];
    
    // Clear our badge count
    [application setApplicationIconBadgeNumber:0];
}

- (void)dealloc {
    [myTableViewController release];
    [window release];
    [super dealloc];
}

// one of these will be called after calling -registerForRemoteNotifications
- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    NSLog(@"We've registered and got back this token: %@", deviceToken);
    // Now we would send it to our server
    // [ServerController associateTokenWithCurrentUser:deviceToken];
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
    NSLog(@"Oh noes! %@", error);
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo {
    // Reload the photos
    [myTableViewController loadFlickrPhotos];
    [[myTableViewController tableView] reloadData];
}

@end
