//
//  MainView.h
//  UserDefaultsDemo
//
//  Created by Chris Marcellino on 1/24/10.
//  Copyright Chris Marcellino 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainView : UIView {
}

@end
